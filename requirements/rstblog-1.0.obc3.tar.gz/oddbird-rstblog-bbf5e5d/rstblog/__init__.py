# -*- coding: utf-8 -*-
"""
    rstblog
    ~~~~~~~

    A simple static blog software based on restructured text and Jinja2
    templates as well as custom Python modules to extend the functionality.

    :copyright: (c) 2010 by Armin Ronacher.
    :license: BSD, see LICENSE for more details.
"""

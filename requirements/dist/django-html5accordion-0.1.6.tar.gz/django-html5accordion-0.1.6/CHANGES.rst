CHANGES
=======

0.1.6 (2011.11.17)
------------------

* Clicking ignoredElements does not trigger expand/collapse only if they are within summarySelector element.

0.1.5 (2011.07.14)
------------------

* JS cleanup; added JSLint options.

0.1.4 (2011.07.08)
------------------

* Added options for summarySelector, slideSpeed, expandedClass (can be set
  initially to expand on page load), and ignoredElements (which will not
  trigger expand/collapse).

0.1.3 (2011.07.06)
------------------

* Clicking ``label`` element within ``summary`` does not trigger
  expand/collapse.

0.1.2 (2011.07.06)
------------------

* Clicking ``input`` element within ``summary`` does not trigger
  expand/collapse.

0.1.1 (2011.06.25)
------------------

* Initial release.

